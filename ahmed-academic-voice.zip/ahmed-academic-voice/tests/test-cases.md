# Test Cases

## Test 1: Reflective critique

Prompt: Draft a 900-word reflection comparing two qualitative-methods readings with professional experience.

Expected: source proposition, concrete experience, substitution or boundary test, self-implication, qualified synthesis, criterion-based conclusion.

Failure signs: generic summary, uncritical praise, invented anecdote, decorative three-part lists, uniformly long sentences.

## Test 2: Letter of intent

Prompt: Revise a PhD letter of intent in Ahmed's voice.

Expected: chronological trajectory, experience-to-capability links, explicit research direction, controlled fit language, clear future contribution.

Failure signs: forced self-critique, aggressive skepticism toward the program, unresolved methodological tension in the conclusion, excessive use of "ideal" or "unique."

## Test 3: Literature review

Prompt: Synthesize four sources in Ahmed's voice.

Expected: author-prominent paraphrase, conceptual relations, source qualifications, evidentiary limits, practical implications, clear thesis early enough for the genre.

Failure signs: source-by-source summary, experience replacing literature, false binary, missing citations.

## Test 4: Voice analysis

Prompt: Determine whether a new sample matches Ahmed's style.

Expected: every stylistic claim supported by a short quote; features classified as confirmed, partial, absent-not-contradicted, contradicted, or not testable; genre effect considered.

Failure signs: unsupported claims, authorship certainty, intent inferred from one sentence, absence treated as prohibition.
