# Quality Checklist

## Genre

- [ ] The document genre and audience are explicit or reasonably inferable.
- [ ] Reflective features are not forced into an application.
- [ ] Promotional application language is not imported into critical analysis.
- [ ] The conclusion matches the genre.

## Voice

- [ ] First person identifies experience, responsibility, interpretation, preparation, or intention.
- [ ] Professional experience is concrete.
- [ ] Experience performs analytical or credibility work rather than decoration.
- [ ] The register is predominantly academic, with only localized conversational phrasing.
- [ ] The prose is direct rather than ornamental.

## Analysis

- [ ] The central claim or tension is visible early enough for the genre.
- [ ] Methodological labels are tested against actual practice where appropriate.
- [ ] Boundary conditions are identified where appropriate.
- [ ] The writer's own assumptions or practice are implicated where warranted.
- [ ] Institutional structures are considered rather than reducing every problem to individual conduct.
- [ ] Ethical intention is distinguished from ethical practice.
- [ ] Participant knowledge and researcher expertise are differentiated without imposing hierarchy.
- [ ] Evidence is connected explicitly to claims.

## Sentence rhythm

- [ ] Most sentences are medium length.
- [ ] Longer sentences contain genuine qualification or linked obligations.
- [ ] Short sentences are used sparingly as analytical brakes.
- [ ] Lists add distinct analytical content.
- [ ] Contrast markers correspond to genuine tensions.
- [ ] Sentence endings carry the sharper distinction or consequence when natural.
- [ ] Paragraphs are not mechanically uniform.

## Academic rigor

- [ ] Source claims retain relevant qualifications.
- [ ] No citation details are invented.
- [ ] Universal terms are supported or moderated.
- [ ] Professional examples are not generalized beyond their demonstrated reach.
- [ ] Rival explanations or limits are addressed when the genre requires them.
- [ ] Proposed methods are not presented as fully settled before context and feasibility are established.

## Negative checks

- [ ] No generic modern-world opening.
- [ ] No ornamental tapestry-style metaphor.
- [ ] No empty "it is important to note."
- [ ] No decorative triplets.
- [ ] No habitual em dashes.
- [ ] No formulaic paragraph-ending slogan.
- [ ] No artificial resolution of every tension.
- [ ] No uncritical praise of every source.
