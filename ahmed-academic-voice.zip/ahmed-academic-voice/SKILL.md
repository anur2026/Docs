---
name: ahmed-academic-voice
description: Reproduce and evaluate Ahmed Orko Nur's academic writing voice across reflective analysis, formal applications, and unfamiliar academic genres. Use when drafting, revising, critiquing, or structurally analyzing text intended to sound like Ahmed. Preserve experience-grounded reasoning, genre modulation, sentence rhythm, authentic quirks, and calibrated academic rigor.
---

# Ahmed Academic Voice

## Purpose

Use this skill to draft, revise, or evaluate text in Ahmed Orko Nur's writing voice. The skill is based on five construction samples and one held-out validation sample.

Do not treat the profile as generic good academic writing. Reproduce Ahmed's documented choices, including first-person situated reasoning, professional experience as analytical evidence, functional enumeration, practical orientation, and genre-dependent modulation.

## Required workflow

1. Identify the genre and audience before drafting.
2. Select the matching mode:
   - critical-reflective academic mode;
   - formal application mode;
   - cross-genre baseline for unfamiliar genres.
3. Identify the document's governing tension, purpose, or intended contribution.
4. Draft using the relevant analysis algorithm and sentence rhythm.
5. Run the voice-preservation and rigor checks in `references/quality-checklist.md`.
6. Revise only where the checks identify a mismatch.
7. If asked to analyze Ahmed's text, support every stylistic claim with a short verbatim quotation. No quote, no claim.

## Cross-genre baseline

Apply these features unless the genre strongly prohibits them:

- Use first person openly when it identifies experience, responsibility, interpretation, preparation, or intended action.
- Establish credibility through concrete academic or professional experience.
- Connect concepts to application, consequence, research design, or institutional practice.
- Use medium-to-long explanatory sentences, with functional variation.
- Use concrete multi-item lists when each item adds analytical substance.
- Maintain a practical orientation and explicit future direction.
- Prefer direct, methodologically informed language over ornament.

Do not make the prose uniformly casual. Ahmed's formal prose is predominantly academic. Conversational language is localized and controlled.

## Genre routing

### Critical-reflective academic mode

Use for reading reflections, methodological critiques, critical response papers, and experience-grounded academic analysis.

Prioritize:

- self-correction;
- professional experience as a methodological stress test;
- substitution testing;
- boundary testing;
- qualified disagreement;
- institutional diagnosis;
- unresolved tensions;
- criterion-based conclusions.

Follow this reasoning sequence:

1. Identify the source proposition with practical consequences.
2. Explain why it attracts attention or resonates.
3. Introduce a concrete professional or institutional situation.
4. Ask whether the practice performs what its label claims.
5. Identify the boundary where the concept becomes a weaker adjacent form.
6. Implicate the writer's own prior assumptions or practice where warranted.
7. Locate relevant structures such as funder priorities, fixed protocols, timelines, or role constraints.
8. Acknowledge the source's value.
9. State its practical, evidentiary, or institutional limit.
10. Separate concepts that have been conflated.
11. Construct a conditional synthesis rather than a total acceptance or rejection.
12. Reclassify apparent failure when it is actually a methodological or institutional condition.
13. Translate the discussion into a design requirement or professional standard.
14. Close with the governing criterion.

Characteristic analytical questions:

- What is this practice called, and what does it actually do?
- Does participation redistribute meaningful influence?
- Does action research shape action or merely accompany it?
- Does the evidence warrant the claim?
- Are roles transparent without treating expertise as interchangeable?
- Does the design preserve place-based particularity?
- Can the method survive the institutional conditions under which it operates?
- Does ethical intention result in ethical practice?

### Formal application mode

Use for letters of intent, statements of purpose, scholarship statements, research-interest statements, and admissions materials.

Prioritize:

- chronological academic and professional trajectory;
- accumulative evidence of preparation;
- experience-to-capability links;
- explicit research direction;
- institutional fit;
- parallel research questions or methodological phases;
- practical contribution;
- commitment-and-fit conclusions.

Do not force self-critique, unresolved tensions, or methodological disagreement into an application merely because they are prominent in reflective writing.

Control promotional language. Claims such as "ideal," "unique," "invaluable," and "aligns closely" may be genre-appropriate, but repeated use makes the voice generic.

### Unfamiliar academic genre

Begin with the cross-genre baseline, then adapt to the genre's actual purpose.

- For a literature review, emphasize source relationships, evidentiary limits, and qualified synthesis.
- For a proposal, state the governing problem early, preserve design uncertainty, and avoid presenting methods as fully settled before context and feasibility are established.
- For a dissertation chapter, move the thesis earlier and represent source qualifications more fully.
- For a technical report, keep first person only where positionality or responsibility requires it; retain concrete evidence, role clarity, and practical criteria.

## Signature analytical moves

Use these selectively, not mechanically:

1. Open through recognition: "This week's readings took me back to familiar terrain..."
2. Identify what previous understanding missed: "What I had not considered carefully enough..."
3. Place prior practice inside the critique.
4. Apply the substitution test: genuinely X or merely Y?
5. Test the boundary: X is not automatically Y.
6. Move from personal difficulty to institutional diagnosis.
7. Distinguish legitimate difference from hierarchy.
8. State a sharp conceptual distinction.
9. Reject a false opposition.
10. Reclassify apparent failure as a methodological or institutional condition when justified.
11. Preserve ethical concern while resisting moralism.
12. Close with a criterion rather than a slogan.

## Sentence rhythm

The baseline rhythm is deliberate, cumulative, and moderately dense.

- Average target for ordinary academic prose: roughly 18 to 24 words per sentence.
- Use longer sentences for genuine qualification, contrast, linked design obligations, or competing responsibilities.
- Use shorter sentences sparingly as analytical brakes.
- Favor an end-weighted structure: context or acknowledgment first, sharper distinction in the final clause.
- Use enumeration to reveal dimensions of a problem, process, competence, or obligation.
- Use contrast markers only when a real tension exists: "but," "while," "rather than," "at the same time," or "by contrast."

A common paragraph rhythm is:

1. orientation;
2. accumulation or explanation;
3. analytical turn;
4. direct distinction;
5. qualification or practical criterion.

Alternative reflective rhythm:

1. experience;
2. complication;
3. self-questioning;
4. revised interpretation.

Avoid uniformly long sentences. Avoid ending every paragraph with a short emphatic claim. The effect depends on scarcity.

## Characteristic contrast structures

Use when analytically justified:

- not X, but Y;
- X is not automatically Y;
- whether X or merely Y;
- X and Y are not the same thing;
- I understand the value of X, but...;
- While I appreciate X, I remain cautious...;
- I do not think these aims have to be opposed.

## Stance and tone

The critical-reflective voice is:

- reflective;
- self-corrective;
- pragmatic;
- candid;
- conditionally skeptical;
- professionally grounded.

Confidence is strongest on operational consequences and more qualified on theoretical or representational questions.

Ethical concern must be joined to role clarity, transparency, evidentiary rigor, faithful representation, and practical consequence. Do not imply that ethical vocabulary proves ethical practice.

## Source integration

- Prefer author-prominent paraphrase over extended quotation.
- Use reporting verbs such as "argues," "emphasizes," "treats," "questions," and "acknowledges."
- Represent source qualifications fairly. Do not compress an author into only the proposition useful to the present argument.
- Use direct quotation mainly for a term or label under examination.
- Follow the requested citation style. Do not invent page numbers or bibliographic details.

## Authentic weaknesses and rigor controls

Preserve the voice, but control these risks:

- delayed thesis placement;
- compressed representation of source arguments;
- universal or intensified wording such as "always" or "infinitely" when evidence is limited;
- professional experience carrying more argumentative weight than its demonstrated reach;
- localized casual phrasing in publication-oriented genres;
- initial binary framing that is only later qualified;
- orderly proposed methods presented as settled before context, feasibility, participant roles, or theory are established.

Improve rigor by:

- making the governing claim visible earlier when the genre requires it;
- calibrating certainty to evidence;
- defining the inferential reach of experience;
- including rival explanations or boundary conditions;
- distinguishing persuasive presentation from evidentiary strength;
- preserving source complexity.

## Negative profile

Avoid habitual use of:

- ornamental metaphors unrelated to the methodological problem;
- generic openings about the modern world;
- "it is important to note" without substantive analytical work;
- mechanical "firstly, secondly, finally" sequencing;
- decorative triplets;
- repeated em dashes;
- uniform paragraph lengths;
- uncritical praise of sources;
- conclusions that merely repeat the discussion;
- artificial balance that resolves every tension;
- impersonal narration when situated responsibility matters.

The corpus does not establish a conscious ban on individual words such as "delve." Treat absence as evidence of non-preference, not prohibition.

## Evaluation mode

When evaluating a document for voice match:

1. Quote the exact passage supporting each claim.
2. Classify each feature as:
   - confirmed;
   - partially confirmed;
   - absent but not contradicted;
   - contradicted;
   - not testable.
3. Separate cross-genre baseline features from genre-specific features.
4. Identify false positives, false negatives, and possible task effects.
5. Do not infer deliberate intent from a single example.
6. Do not generalize from absence in a short sample.
7. Do not call a pattern consistent unless it appears across most relevant samples.

## Final output check

Before returning a draft, verify:

- Is the genre correctly identified?
- Is first person serving a clear rhetorical function?
- Does experience perform analytical or credibility work?
- Are concepts connected to application?
- Are lists functional rather than decorative?
- Does sentence length vary with reasoning?
- Are analytical contrasts genuine?
- Is certainty calibrated to evidence?
- Are source arguments represented fairly?
- Does the conclusion fit the genre?
- Have generic AI phrases and ornamental language been removed?
- Has the voice been preserved without copying sample sentences unless quotation is explicitly requested?

Read `references/style-profile.md` for the full operational profile and `references/quality-checklist.md` for the final review rubric.
